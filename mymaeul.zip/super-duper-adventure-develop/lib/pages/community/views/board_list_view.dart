import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:get/get.dart';
import 'post_detail_view.dart';
import 'post_create_view.dart';
import '../controllers/post_create_controller.dart';
import '../../../routes/app_routes.dart';

class BoardListView extends StatefulWidget {
  final String category;
  final String villageName;
  final String villageId;

  const BoardListView({
    super.key,
    this.category = '',
    this.villageName = '',
    this.villageId = '',
  });

  @override
  State<BoardListView> createState() => _BoardListViewState();
}

class _BoardListViewState extends State<BoardListView> {
  String _selectedCategory = '전체';
  late List<String> _categories = ['전체', '일상', '게임', '취미', '퀴즈'];
  bool _showDrawer = false;
  bool _notificationEnabled = true;
  bool _isEditMode = false;

  @override
  void initState() {
    super.initState();
    _selectedCategory = widget.category;
  }

  Stream<QuerySnapshot> _getPostStream() {
    Query query = FirebaseFirestore.instance
        .collection('villages')
        .doc(widget.villageId)
        .collection('posts');

    if (_selectedCategory != '전체') {
      query = query.where('category', isEqualTo: _selectedCategory);
    }

    return query.orderBy('createdAt', descending: true).snapshots();
  }

  Future<DocumentSnapshot?> _getPinnedPost() async {
    try {
      final QuerySnapshot result = await FirebaseFirestore.instance
          .collection('villages')
          .doc(widget.villageId)
          .collection('posts')
          .where('isPinned', isEqualTo: true)
          .orderBy('createdAt', descending: true)
          .limit(1)
          .get();

      debugPrint('공지 조회 결과: ${result.docs.length}개');
      if (result.docs.isNotEmpty) {
        final data = result.docs.first.data() as Map<String, dynamic>;
        debugPrint('공지 데이터: $data');
        return result.docs.first;
      }
      return null;
    } catch (e) {
      debugPrint('공지 조회 오류: $e');
      return null;
    }
  }

  String _formatTimestamp(Timestamp? timestamp) {
    if (timestamp == null) return '방금 전';
    DateTime date = timestamp.toDate();
    return '${date.month}.${date.day.toString().padLeft(2, '0')}';
  }

  void _showAddCategoryDialog() {
    final TextEditingController controller = TextEditingController();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            '카테고리 추가',
            style: GoogleFonts.gowunDodum(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          content: TextField(
            controller: controller,
            decoration: InputDecoration(
              hintText: '카테고리 이름 입력',
              hintStyle: GoogleFonts.gowunDodum(fontSize: 14),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            style: GoogleFonts.gowunDodum(fontSize: 14),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(
                '취소',
                style: GoogleFonts.gowunDodum(color: Colors.grey),
              ),
            ),
            TextButton(
              onPressed: () {
                final String categoryName = controller.text.trim();
                if (categoryName.isNotEmpty &&
                    !_categories.contains(categoryName)) {
                  setState(() {
                    _categories.insert(_categories.length - 1, categoryName);
                  });
                  Navigator.of(context).pop();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        categoryName.isEmpty
                            ? '카테고리 이름을 입력해주세요'
                            : '이미 존재하는 카테고리입니다',
                        style: GoogleFonts.gowunDodum(),
                      ),
                    ),
                  );
                }
              },
              child: Text(
                '추가',
                style: GoogleFonts.gowunDodum(color: Colors.blue),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [_buildCategoryView(), if (_showDrawer) _buildDrawerView()],
    );
  }

  Widget _buildDrawerView() {
    return Stack(
      children: [
        // 배경 (반투명)
        GestureDetector(
          onTap: () {
            setState(() {
              _showDrawer = false;
            });
          },
          child: Container(color: Colors.black.withOpacity(0.3)),
        ),
        // 드로어
        Positioned(
          right: 0,
          top: 0,
          bottom: 0,
          width: 280,
          child: Container(
            color: Colors.white,
            child: Column(
              children: [
                // 드로어 헤더
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 16,
                  ),
                  color: const Color(0xFFC4ECF6),
                  height: 151,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: () {
                              setState(() {
                                _notificationEnabled = !_notificationEnabled;
                              });
                            },
                            child: Icon(
                              _notificationEnabled
                                  ? Icons.notifications
                                  : Icons.notifications_off,
                              size: 24,
                              color: Colors.black,
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              setState(() {
                                _isEditMode = !_isEditMode;
                              });
                            },
                            child: Text(
                              _isEditMode ? '완료' : '편집',
                              style: GoogleFonts.gowunDodum(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // 카테고리 목록
                Expanded(
                  child: _isEditMode
                      ? ReorderableListView(
                          buildDefaultDragHandles: false,
                          children: _categories.asMap().entries.map((entry) {
                            int index = entry.key;
                            String category = entry.value;
                            return Container(
                              key: ValueKey(category),
                              child: GestureDetector(
                                onTap: () {},
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 16,
                                  ),
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: Colors.grey[200]!,
                                      ),
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          ReorderableDragStartListener(
                                            index: index,
                                            child: Padding(
                                              padding: const EdgeInsets.only(
                                                right: 8.0,
                                              ),
                                              child: Icon(
                                                Icons.drag_handle,
                                                size: 20,
                                                color: Colors.grey[600],
                                              ),
                                            ),
                                          ),
                                          Text(
                                            category,
                                            style: GoogleFonts.gowunDodum(
                                              color: Colors.black,
                                              fontSize: 14,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        ],
                                      ),
                                      if (category != '전체' && category != '퀴즈')
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              _categories.remove(category);
                                              if (_selectedCategory ==
                                                  category) {
                                                _selectedCategory = '전체';
                                              }
                                            });
                                          },
                                          child: Text(
                                            '삭제',
                                            style: GoogleFonts.gowunDodum(
                                              color: Colors.grey,
                                              fontSize: 14,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                          onReorder: (oldIndex, newIndex) {
                            setState(() {
                              if (oldIndex < newIndex) {
                                newIndex -= 1;
                              }
                              final item = _categories.removeAt(oldIndex);
                              _categories.insert(newIndex, item);
                            });
                          },
                          footer: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 16,
                            ),
                            decoration: BoxDecoration(
                              border: Border(
                                bottom: BorderSide(color: Colors.grey[200]!),
                              ),
                            ),
                            child: GestureDetector(
                              onTap: () {
                                _showAddCategoryDialog();
                              },
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.add,
                                    size: 20,
                                    color: Colors.grey[600],
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    '카테고리 추가',
                                    style: GoogleFonts.gowunDodum(
                                      color: Colors.black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                      : ListView(
                          children: _categories.asMap().entries.map((entry) {
                            String category = entry.value;
                            return GestureDetector(
                              onTap: () {
                                if (_isEditMode) {
                                  return;
                                }
                                if (category == '퀴즈') {
                                  Get.toNamed(
                                    AppRoutes.quiz,
                                    arguments: {
                                      'villageName': widget.villageName,
                                      'villageId': widget.villageId,
                                    },
                                  );
                                } else {
                                  setState(() {
                                    _selectedCategory = category;
                                    _showDrawer = false;
                                  });
                                }
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 16,
                                ),
                                decoration: BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                      color: Colors.grey[200]!,
                                    ),
                                  ),
                                ),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    category,
                                    style: GoogleFonts.gowunDodum(
                                      color: Colors.black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCategoryView() {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment(0.50, 1.00),
                end: Alignment(0.50, 0.00),
                colors: [Color(0xFFC4ECF6), Color(0xFF4CDBFF)],
              ),
            ),
            child: SafeArea(
              bottom: false,
              child: Column(
                children: [
                  // 마이마을 로고와 마을 이름
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 16,
                    ),
                    child: Stack(
                      children: [
                        // 왼쪽: 마이마을 로고
                        Align(
                          alignment: Alignment.centerLeft,
                          child: GestureDetector(
                            onTap: () {
                              Get.toNamed(AppRoutes.mainHome);
                            },
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  '마이',
                                  style: GoogleFonts.bagelFatOne(
                                    color: Colors.white,
                                    fontSize: 24,
                                    fontWeight: FontWeight.w400,
                                    letterSpacing: 1,
                                  ),
                                ),
                                Text(
                                  '마을',
                                  style: GoogleFonts.bagelFatOne(
                                    color: Colors.white,
                                    fontSize: 24,
                                    fontWeight: FontWeight.w400,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        // 중앙: 마을 이름
                        Center(
                          child: GestureDetector(
                            onTap: () {
                              Get.back();
                            },
                            child: Text(
                              widget.villageName,
                              style: GoogleFonts.gowunDodum(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ),
                        // 오른쪽: 검색 아이콘
                        Align(
                          alignment: Alignment.centerRight,
                          child: GestureDetector(
                            onTap: () {
                              Get.toNamed(
                                AppRoutes.search,
                                arguments: {
                                  'villageName': widget.villageName,
                                  'villageId': widget.villageId,
                                },
                              );
                            },
                            child: const Icon(
                              Icons.search,
                              color: Colors.white,
                              size: 28,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // 카테고리 탭
          Container(
            width: double.infinity,
            height: 45,
            decoration: const BoxDecoration(color: Color(0xFFC4ECF6)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children:
                  _categories.map((category) {
                    final isSelected = category == _selectedCategory;
                    return GestureDetector(
                      onTap: () {
                        if (category == '퀴즈') {
                          Get.toNamed(
                            AppRoutes.quiz,
                            arguments: {
                              'villageName': widget.villageName,
                              'villageId': widget.villageId,
                            },
                          );
                        } else {
                          setState(() {
                            _selectedCategory = category;
                          });
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              category,
                              style: GoogleFonts.gowunDodum(
                                color: isSelected
                                    ? Colors.black
                                    : const Color(0xFF6D6D6D),
                                fontSize: 20,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                            const SizedBox(height: 4),
                            if (isSelected)
                              Container(
                                width: 36,
                                height: 3,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF07C7F7),
                                  borderRadius: BorderRadius.circular(5),
                                ),
                              ),
                          ],
                        ),
                      ),
                    );
                  }).toList()..add(
                    // 메뉴 아이콘
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _showDrawer = !_showDrawer;
                        });
                      },
                      child: const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8),
                        child: Icon(Icons.menu, color: Colors.white, size: 24),
                      ),
                    ),
                  ),
            ),
          ),

          // 공지 영역
          FutureBuilder<DocumentSnapshot?>(
            future: _getPinnedPost(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SizedBox.shrink();
              }

              if (!snapshot.hasData || snapshot.data == null) {
                return const SizedBox.shrink();
              }

              final pinnedPost = snapshot.data!.data() as Map<String, dynamic>;
              final pinnedTitle = pinnedPost['title'] ?? '공지';

              return GestureDetector(
                onTap: () {
                  Get.toNamed(AppRoutes.mainHome);
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 17,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFB9B9B9).withOpacity(0.3),
                        blurRadius: 10,
                        offset: const Offset(0, 1),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFF4CDBFF),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '공지',
                          style: GoogleFonts.gowunDodum(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          pinnedTitle,
                          style: GoogleFonts.gowunDodum(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),

          // 게시글 목록
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _getPostStream(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (snapshot.hasError) {
                  return Center(child: Text('에러: ${snapshot.error}'));
                }

                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Center(
                    child: Text(
                      "'$_selectedCategory' 게시글이 없습니다.",
                      style: GoogleFonts.gowunDodum(fontSize: 16),
                    ),
                  );
                }

                final docs = snapshot.data!.docs;

                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final data = docs[index].data() as Map<String, dynamic>;
                    String author = data['author'] ?? '익명';
                    int commentCount = data['commentCount'] ?? 0;

                    return _PostCard(
                      postId: docs[index].id,
                      villageId: widget.villageId,
                      title: data['title'] ?? '제목 없음',
                      author: author,
                      time: _formatTimestamp(data['createdAt']),
                      comments: commentCount.toString(),
                      hasImage: data['imageUrl'] != null,
                      imageUrl: data['imageUrl'] as String?,
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.to(
            () => const PostCreateView(),
            binding: BindingsBuilder(() {
              Get.lazyPut(
                () => PostCreateController(
                  villageName: widget.villageName,
                  villageId: widget.villageId,
                ),
              );
            }),
          );
        },
        backgroundColor: const Color(0xFF4CDBFF),
        shape: const CircleBorder(
          side: BorderSide(color: const Color(0xFF0094FF), width: 3),
        ),
        child: const Icon(Icons.edit, color: Colors.white, size: 24),
      ),
    );
  }
}

class _PostCard extends StatelessWidget {
  final String postId;
  final String villageId;
  final String title;
  final String author;
  final String time;
  final String comments;
  final bool hasImage;
  final String? imageUrl;

  const _PostCard({
    required this.postId,
    required this.villageId,
    required this.title,
    required this.author,
    required this.time,
    required this.comments,
    this.hasImage = false,
    this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Get.to(() => PostDetailScreen(postId: postId, villageId: villageId));
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
        decoration: const BoxDecoration(
          border: Border(
            bottom: BorderSide(color: Color(0xFFE0E0E0), width: 1),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.gowunDodum(
                      fontWeight: FontWeight.w400,
                      fontSize: 20,
                      color: Colors.black,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '$author | $time | $comments',
                    style: GoogleFonts.gowunDodum(
                      fontWeight: FontWeight.w400,
                      fontSize: 14,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
            if (hasImage && imageUrl != null) ...[
              const SizedBox(width: 12),
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFFC4ECF6), width: 3),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(2),
                  child: Image.network(
                    imageUrl!,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        color: const Color(0xFFE0E0E0),
                        child: const Icon(Icons.image, color: Colors.grey),
                      );
                    },
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
